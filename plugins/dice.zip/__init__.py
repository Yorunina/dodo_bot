from .dice import *
__version__ = "1.0.1"