from .yiyan import *
__version__ = "1.0.1"